import requests
from time import sleep
from imports.styles import *

# give a few minutes before updating once an update is released so the update can
# register on github :)
# if Coldheart reports that it's up to date but you know it's not, re-run the 
# script to check for updates again
def update(COLDHEART):
	prints.info("Checking for new version of Coldheart... (CTRL-C to abort)")
	try:
		sleep(3)
		coldheart = open(COLDHEART,'r')
		for line in coldheart.readlines():
			if "version" in line:
				script_version = (line[9:]).strip('\n')
				break
		coldheart.close()

		r = requests.get("https://raw.githubusercontent.com/ProjectColdheart/LinuxColdheart/master/version.txt")
		cur_version = str((r.text)).strip('\n')

		if script_version == cur_version:
			prints.good("Coldheart Up To Date. [Version %s]" % (cur_version))
		else:
			prints.info("Found new version: %s" % (cur_version))
			prints.info("Updating Coldheart to version %s..." % (cur_version))
			try:
				r = requests.get("https://raw.githubusercontent.com/ProjectColdheart/LinuxColdheart/master/ch.py")
				script = open(COLDHEART,'w')
				script.write(r.text)
				script.close()
				prints.good("Update Complete.")
			except:
				prints.bad("Update Failed!")
	except KeyboardInterrupt:
		prints.warning("Update check aborted! Re-run Coldheart to check for update!")
