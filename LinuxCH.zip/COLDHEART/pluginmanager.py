from __future__ import print_function
from imports.styles import *
import sys
import os

plugins = []

CONFIG_EXT = '.ch'

# Path to plugin manager, and path to it without script name
PM, PM_DIR = os.path.realpath(__file__), os.path.dirname(__file__)

plugin_dir = os.path.join(PM_DIR, 'plugins')

# For everything in the plugin directory
for root, dirs, files in os.walk(plugin_dir):
	# For all of the dirs in the plugin directory
	for dir in dirs:
		# For plugin dir in 'plugins' dir
		for root2, dirs2, files2 in os.walk(os.path.join(plugin_dir, dir)):
			# For every file in the plugin dir
			for file in files2:
				# If a valid file exists, the plugin is valid
				if file == 'valid':
					plugins.append(dir)
				else:
					pass

print('=-' * 4 + '= Valid Plugins ' + '=-' * 4, end='=\n')

if len(plugins) == 0:
	prints.bad('No valid plugins found!')
else:
	# Print the index of the plugin as well as the name
	for plugin in plugins:
		prints.info('[%s] %s' % (plugins.index(plugin), plugin))

sel = int(raw_input(styles.question + "Which plugin to load?: "))

val = False

for plugin in plugins:
	if sel == plugins.index(plugin):
		val = True
		break
	else:
		pass
		
if not val:
	prints.bad('Not a valid plugin! Now exiting!')
	sys.exit(0)
	
		

prints.info('Loading %s\'s config file ' % (plugins[int(sel)]))

# Open the selected plugins config file
with open(os.path.join(plugin_dir, plugins[int(sel)]) + '/config' + CONFIG_EXT, 'r') as config:
	lines = config.readlines()
	for line in lines:
		line = line.rstrip('\n')
	print(lines)
		
		
		
		
		
		
		
		
