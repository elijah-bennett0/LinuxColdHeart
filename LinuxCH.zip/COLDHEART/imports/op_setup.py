import os, os.path
from imports.styles import *

OPS = []

def load_op(dir):
	for obj in os.listdir(dir):
		if os.path.isfile(("%s/%s") % (dir, obj)):
			pass
		else:
			OPS.append(obj.lower())
	if len(OPS) == 0:
		prints.bad("No OPS Found!")	
	else:	
		for op in OPS:
			prints.good("OP Found: %s\n" % op)
		
def new_op(dir):
	name = raw_input(styles.question + "OP Name > ")
	try:
		os.mkdir("%s/%s" % (dir, name))
		prints.good("OP %s created." % (name))
	except:
		prints.bad("Could not create OP.")
def del_op(dir):
	for obj in os.listdir(dir):
		if os.path.isfile(("%s/%s") % (dir, obj)):
			pass
		else:
			if len(OPS) == 0:
				OPS.append(obj.lower())
			else:
				for obj2 in OPS:
					if obj.lower() == obj2.lower():
						pass
					else:
						OPS.append(obj.lower())
	if len(OPS) == 0:
		prints.bad("No OPS Found!")
	else:	
		for op in OPS:
			prints.good("OP Found: %s\n" % op)
	if len(OPS) != 0:
		d_op = raw_input(styles.question + "OP name to delete > ")
		try:
			os.rmdir("%s/%s" % (dir, d_op))
			prints.good("OP removed.")
		except:
			prints.bad("Could not remove OP.")
