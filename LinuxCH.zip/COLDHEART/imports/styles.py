import pip
try:
	from colorama import Fore, Back, Style, init
except:
	print("Colorama not found, installing now...")
	pip.main(['install', 'colorama'])
	from colorama import Fore, Back, Style, init
class styles_:
	reset = Style.RESET_ALL
	question = Style.BRIGHT + Fore.MAGENTA + "[?] " + reset
styles = styles_()
class prints_:
	def good(self, s):
		print(Style.BRIGHT + Fore.GREEN + "[+] " + styles.reset + s)
	def bad(self, s):
		print(Style.BRIGHT + Fore.RED + "[-] " + styles.reset + s)
	def info(self, s):
		print(Style.BRIGHT + Fore.BLUE + "[*] " + styles.reset + s)
	def warning(self, s):
		print(Style.BRIGHT + Fore.YELLOW + "[!] " + styles.reset + s)
prints = prints_()


